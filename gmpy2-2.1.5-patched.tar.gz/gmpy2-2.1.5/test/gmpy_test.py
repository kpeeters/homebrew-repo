from __future__ import print_function

print("\nImportant test information!\n")
print("Please use 'test/runtests.py' to run the new test suite.\n")
